export async function testSciencePlan() {
  // TODO: logic ref doc
}
