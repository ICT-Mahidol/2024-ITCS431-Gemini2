export function SpaceBackground() {
  return <></>;
}
