export async function deleteSciencePlan() {
  // TODO: logic ref doc
}
